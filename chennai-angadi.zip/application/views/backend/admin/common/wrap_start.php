<?php  
$backend_theme_url=$this->config->item('backend_theme_url'); 
$admin_url=$this->config->item('admin_url');
$base_url=$this->config->item('base_url'); 
 ?>

<!-- END HEADER --> 
<!-- BEGIN CONTAINER -->
<div class="page-container row-fluid"> 


 
   <div class="footer-widget">		
	<div class=" progress-success progress-small no-radius no-margin">
			
	</div>
	<div class="pull-right">
	<a href="<?php echo $base_url ; ?>manage"></a></div>
  </div>