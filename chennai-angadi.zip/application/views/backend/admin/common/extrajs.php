<?php $backend_theme_url=$this->config->item('backend_theme_url'); ?>
<script src="<?php echo   $backend_theme_url ?>plugins/jquery-datatable/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="<?php echo   $backend_theme_url ?>plugins/jquery-datatable/extra/js/TableTools.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo   $backend_theme_url ?>plugins/datatables-responsive/js/datatables.responsive.js"></script>
<script type="text/javascript" src="<?php echo   $backend_theme_url ?>plugins/datatables-responsive/js/lodash.min.js"></script>
<!-- END PAGE LEVEL PLUGINS -->
<!-- <script src="<?php echo   $backend_theme_url ?>js/form_elements.js" type="text/javascript"></script> -->
<script src="<?php echo   $backend_theme_url ?>js/datatables.js" type="text/javascript"></script>
<script src="<?php echo   $backend_theme_url ?>js/demo.js" type="text/javascript"></script>
<link href="<?php echo   $backend_theme_url ?>plugins/jquery-datatable/css/jquery.dataTables.css" rel="stylesheet" type="text/css" />


